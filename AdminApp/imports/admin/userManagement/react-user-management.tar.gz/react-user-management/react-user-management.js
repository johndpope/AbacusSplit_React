// Write your package code here!

// Variables exported by this module can be imported by other packages and
// applications. See react-user-management-tests.js for an example of importing.
export const name = 'react-user-management';
